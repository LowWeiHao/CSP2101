#!/bin/bash
ls -R ~
#list home directory's directory structure.