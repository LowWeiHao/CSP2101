#!/bin/bash
rm --help
#list the option of delete file
