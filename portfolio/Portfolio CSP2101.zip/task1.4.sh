#!/bin/bash
chmod 444 Hello_World.sh
#change mode of file.
