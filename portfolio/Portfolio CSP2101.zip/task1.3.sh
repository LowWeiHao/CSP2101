#!/bin/bash
ls -1aZl
#list all content in current folder.