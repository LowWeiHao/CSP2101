#!/bin/bash
read -p "Name the new folder: " FolderName
#ask for folder name.
mkdir "$FolderName"
#create folder.