#!/bin/bash
#Student Name: Low Wei Hao
#Student ID: 10522673

grep -rE 'Rec[0-9]*,? [0-9]*, [0-9]*, [0-9]*?[0-9]{3}, red$' Rectangle.txt 